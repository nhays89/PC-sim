#include "assemblerGUI.h"

int main()
{
    startGTK();

   return 0;
}
